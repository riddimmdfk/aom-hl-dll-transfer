﻿$ErrorActionPreference = 'Stop'
$OriginalSha256 = '8a843e35e0bd2ce1778dd1f083c986fa023d8654c499e45156ef7280e38c0798'
$PatchedSha256  = 'ccbbf2f63f96160810bf190c6fb5c2c3672ed8e31e1bbf8a76253ba1800531c5'
$LegacyV01Sha256 = '8933eeaf71c0e494442ab681bf65f8eb80fc013d7c320d32cb8d5dfe4727f8e5'
function Get-Sha256([string]$Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Wait-End { Read-Host 'Нажмите Enter для закрытия окна' | Out-Null }
try {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        $argLine = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '"'
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $argLine
        exit 0
    }
    if (Get-Process -Name 'hl' -ErrorAction SilentlyContinue) { throw 'Half-Life сейчас запущена. Закрой игру перед восстановлением.' }
    $pf86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
    if ([string]::IsNullOrWhiteSpace($pf86)) { $pf86 = $env:ProgramFiles }
    $defaultRoot = Join-Path $pf86 'Steam\steamapps\common\Half-Life'
    $entered = Read-Host "Папка Half-Life (Enter = $defaultRoot)"
    if ([string]::IsNullOrWhiteSpace($entered)) { $root = $defaultRoot } else { $root = $entered.Trim().Trim('"') }
    $root = [IO.Path]::GetFullPath($root)
    $target = Join-Path $root 'hw.dll'
    $backup = $target + '.aom-audio-original'
    $temp = $target + '.aom-audio-restore'
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Не найден hw.dll: $target" }
    $currentHash = Get-Sha256 $target
    if ($currentHash -eq $OriginalSha256) {
        Write-Host 'Оригинальный hw.dll уже установлен. Резервная копия не удалена.' -ForegroundColor Green
        Wait-End; exit 0
    }
    if ($currentHash -ne $PatchedSha256 -and $currentHash -ne $LegacyV01Sha256) {
        throw "Текущий hw.dll не совпадает ни с v0.2, ни с известной v0.1. Получена SHA-256: $currentHash. Файл не изменён."
    }
    if (-not (Test-Path -LiteralPath $backup -PathType Leaf)) { throw "Не найдена резервная копия: $backup" }
    if ((Get-Sha256 $backup) -ne $OriginalSha256) { throw 'Резервная копия не прошла проверку SHA-256. Файл не изменён.' }
    if (Test-Path -LiteralPath $temp) { throw "Уже существует временный файл: $temp" }
    Copy-Item -LiteralPath $backup -Destination $temp
    if ((Get-Sha256 $temp) -ne $OriginalSha256) { throw 'Временная копия оригинала не прошла проверку.' }
    Move-Item -LiteralPath $temp -Destination $target -Force
    if ((Get-Sha256 $target) -ne $OriginalSha256) { throw 'Проверка восстановленного hw.dll не прошла.' }
    Write-Host ''
    Write-Host 'Оригинальный hw.dll восстановлен.' -ForegroundColor Green
    Write-Host "Резервная копия сохранена: $backup"
    Write-Host 'Файлы .aom-audio рядом с сохранениями не удаляются.'
    Wait-End
}
catch {
    Write-Host ''
    Write-Host ('ОШИБКА: ' + $_.Exception.Message) -ForegroundColor Red
    Wait-End
    exit 1
}
