﻿$ErrorActionPreference = 'Stop'
$OriginalSha256 = '8a843e35e0bd2ce1778dd1f083c986fa023d8654c499e45156ef7280e38c0798'
$PatchedSha256  = 'ccbbf2f63f96160810bf190c6fb5c2c3672ed8e31e1bbf8a76253ba1800531c5'
$LegacyV01Sha256 = '8933eeaf71c0e494442ab681bf65f8eb80fc013d7c320d32cb8d5dfe4727f8e5'

function Get-Sha256([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}
function Wait-End { Read-Host 'Нажмите Enter для закрытия окна' | Out-Null }

try {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        $argLine = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '"'
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $argLine
        exit 0
    }

    if (Get-Process -Name 'hl' -ErrorAction SilentlyContinue) {
        throw 'Half-Life сейчас запущена. Полностью закрой игру перед установкой.'
    }

    $pf86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
    if ([string]::IsNullOrWhiteSpace($pf86)) { $pf86 = $env:ProgramFiles }
    $defaultRoot = Join-Path $pf86 'Steam\steamapps\common\Half-Life'
    $entered = Read-Host "Папка Half-Life (Enter = $defaultRoot)"
    if ([string]::IsNullOrWhiteSpace($entered)) { $root = $defaultRoot } else { $root = $entered.Trim().Trim('"') }
    $root = [IO.Path]::GetFullPath($root)

    $target = Join-Path $root 'hw.dll'
    $backup = $target + '.aom-audio-original'
    $temp = $target + '.aom-audio-new'
    $patch = Join-Path $PSScriptRoot 'hw_audio_resume_persistent_experimental.dll'

    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Не найден файл: $target" }
    if (-not (Test-Path -LiteralPath $patch -PathType Leaf)) { throw 'В архиве отсутствует экспериментальная DLL.' }
    if (Test-Path -LiteralPath $temp) { throw "Найден временный файл $temp. Удали его после проверки." }

    $currentHash = Get-Sha256 $target
    if ($currentHash -eq $PatchedSha256) { throw 'Экспериментальная v0.2 уже установлена.' }

    if (Test-Path -LiteralPath $backup) {
        $backupHash = Get-Sha256 $backup
        if ($backupHash -ne $OriginalSha256) {
            throw "Существующая резервная копия не совпадает с проверенным оригиналом: $backupHash. Ничего не изменено."
        }
        if ($currentHash -eq $LegacyV01Sha256) {
            Write-Host 'Обнаружена предыдущая v0.1. Возвращаю проверенный оригинал перед обновлением.' -ForegroundColor Yellow
            Copy-Item -LiteralPath $backup -Destination $temp
            if ((Get-Sha256 $temp) -ne $OriginalSha256) { throw 'Не прошла проверка временной копии оригинала.' }
            Move-Item -LiteralPath $temp -Destination $target -Force
            $currentHash = Get-Sha256 $target
        }
    }

    if ($currentHash -ne $OriginalSha256) {
        throw "Версия hw.dll не совпадает с проверенной. Ожидалась SHA-256 $OriginalSha256, получена $currentHash. Файл не изменён."
    }

    if (-not (Test-Path -LiteralPath $backup)) {
        Copy-Item -LiteralPath $target -Destination $backup
        if ((Get-Sha256 $backup) -ne $OriginalSha256) { throw 'Резервная копия не прошла проверку. Оригинал не заменён.' }
    }

    $patchHash = Get-Sha256 $patch
    if ($patchHash -ne $PatchedSha256) { throw "SHA-256 патча не совпала: $patchHash" }

    Copy-Item -LiteralPath $patch -Destination $temp
    if ((Get-Sha256 $temp) -ne $PatchedSha256) { throw 'Временная копия патча не прошла проверку.' }

    try {
        Move-Item -LiteralPath $temp -Destination $target -Force
        if ((Get-Sha256 $target) -ne $PatchedSha256) { throw 'Проверка установленного файла не прошла.' }
    }
    catch {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue }
        if (Test-Path -LiteralPath $backup) { Copy-Item -LiteralPath $backup -Destination $target -Force -ErrorAction SilentlyContinue }
        throw
    }

    Write-Host ''
    Write-Host 'Экспериментальная AOM Audio Resume v0.2 установлена.' -ForegroundColor Green
    Write-Host "hw.dll: $target"
    Write-Host "Резервная копия: $backup"
    Write-Host "Файл состояния будет записываться в: $(Join-Path $root 'aom\SAVE\<слот>.aom-audio')"
    Write-Host 'После quicksave не удаляй соответствующий .aom-audio: он нужен для загрузки после перезапуска игры.'
    Wait-End
}
catch {
    Write-Host ''
    Write-Host ('ОШИБКА: ' + $_.Exception.Message) -ForegroundColor Red
    Wait-End
    exit 1
}
