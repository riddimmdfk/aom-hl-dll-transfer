.intel_syntax noprefix
.section .text,"ax"
.code32
.global PatchStart
PatchStart:

/* Return the runtime base of the injected section. */
GetPatchBase:
    call .Lgetbase
.Lgetbase:
    pop eax
    sub eax, 5
    ret

.equ PATCH_VA, 0x114AA000
.equ CHAN_TABLE_VA, 0x111C2EC0
.equ SOUND_TIME_VA, 0x111C2EB0
.equ S_START_STATIC_SOUND_VA, 0x101FE780
.equ S_FIND_NAME_VA, 0x101FD540
.equ HOST_LOAD_IMPL_VA, 0x101CD8D0
.equ SAVE_IMPL_VA, 0x101D1680
.equ IAT_GETMODULEHANDLEA_VA, 0x102B2138
.equ IAT_GETPROCADDRESS_VA, 0x102B2134

.global PatchSaveWrapper
.global PatchLoadWrapper

PatchSaveWrapper:
    push ebp
    mov ebp, esp
    push ebx
    call GetPatchBase
    mov ebx, eax

    /* Snapshot the active target channels before serialization. */
    pushfd
    pushad
    push dword ptr [ebp+8]
    call CaptureState
    add esp, 4
    popad
    popfd

    /* Original SaveGame(name, comment). */
    push dword ptr [ebp+0x0c]
    push dword ptr [ebp+8]
    mov eax, SAVE_IMPL_VA - PATCH_VA
    add eax, ebx
    call eax
    add esp, 8

    /* SaveGame returns 1 only after the save file has been written. */
    test eax, eax
    jz .Lsave_return
    push eax
    pushfd
    pushad
    push dword ptr [ebp+8]
    call WriteSidecar
    add esp, 4
    popad
    popfd
    pop eax
.Lsave_return:
    pop ebx
    mov esp, ebp
    pop ebp
    ret

PatchLoadWrapper:
    push ebp
    mov ebp, esp
    push ebx
    call GetPatchBase
    mov ebx, eax

    /* Run the genuine loader first. */
    push dword ptr [ebp+8]
    mov eax, HOST_LOAD_IMPL_VA - PATCH_VA
    add eax, ebx
    call eax
    add esp, 4
    test eax, eax
    jz .Lload_return

    /* A persisted sidecar is loaded only after successful .sav loading. */
    push eax
    pushfd
    pushad
    push dword ptr [ebp+8]
    call ReadSidecar
    add esp, 4
    test eax, eax
    jz .Lno_restore
    push dword ptr [ebp+8]
    call RestoreState
    add esp, 4
.Lno_restore:
    popad
    popfd
    pop eax
.Lload_return:
    pop ebx
    mov esp, ebp
    pop ebp
    ret

/* Resolve Win32 file APIs dynamically, avoiding new PE import entries. */
ResolveApis:
    push ebp
    mov ebp, esp
    push ebx
    push esi
    push edi
    call GetPatchBase
    mov ebx, eax

    lea eax, [ebx + KERNEL32_A_OFF]
    push eax
    lea eax, [ebx + IAT_GETMODULEHANDLEA_VA - PATCH_VA]
    call dword ptr [eax]
    test eax, eax
    jz .Lresolve_fail
    mov esi, eax

    /* GetProcAddress(GetModuleHandleA("kernel32.dll"), name). */
    lea eax, [ebx + API_GETMODULEFILENAMEW_OFF]
    push eax
    push esi
    lea eax, [ebx + IAT_GETPROCADDRESS_VA - PATCH_VA]
    call dword ptr [eax]
    mov dword ptr [ebx + PTR_GETMODULEFILENAMEW_OFF], eax

    lea eax, [ebx + API_CREATEFILEW_OFF]
    push eax
    push esi
    lea eax, [ebx + IAT_GETPROCADDRESS_VA - PATCH_VA]
    call dword ptr [eax]
    mov dword ptr [ebx + PTR_CREATEFILEW_OFF], eax

    lea eax, [ebx + API_WRITEFILE_OFF]
    push eax
    push esi
    lea eax, [ebx + IAT_GETPROCADDRESS_VA - PATCH_VA]
    call dword ptr [eax]
    mov dword ptr [ebx + PTR_WRITEFILE_OFF], eax

    lea eax, [ebx + API_READFILE_OFF]
    push eax
    push esi
    lea eax, [ebx + IAT_GETPROCADDRESS_VA - PATCH_VA]
    call dword ptr [eax]
    mov dword ptr [ebx + PTR_READFILE_OFF], eax

    lea eax, [ebx + API_CLOSEHANDLE_OFF]
    push eax
    push esi
    lea eax, [ebx + IAT_GETPROCADDRESS_VA - PATCH_VA]
    call dword ptr [eax]
    mov dword ptr [ebx + PTR_CLOSEHANDLE_OFF], eax

    lea eax, [ebx + API_DELETEFILEW_OFF]
    push eax
    push esi
    lea eax, [ebx + IAT_GETPROCADDRESS_VA - PATCH_VA]
    call dword ptr [eax]
    mov dword ptr [ebx + PTR_DELETEFILEW_OFF], eax

    mov eax, 1
    cmp dword ptr [ebx + PTR_GETMODULEFILENAMEW_OFF], 0
    je .Lresolve_fail
    cmp dword ptr [ebx + PTR_CREATEFILEW_OFF], 0
    je .Lresolve_fail
    cmp dword ptr [ebx + PTR_WRITEFILE_OFF], 0
    je .Lresolve_fail
    cmp dword ptr [ebx + PTR_READFILE_OFF], 0
    je .Lresolve_fail
    cmp dword ptr [ebx + PTR_CLOSEHANDLE_OFF], 0
    je .Lresolve_fail
    cmp dword ptr [ebx + PTR_DELETEFILEW_OFF], 0
    je .Lresolve_fail
    jmp .Lresolve_done
.Lresolve_fail:
    xor eax, eax
.Lresolve_done:
    pop edi
    pop esi
    pop ebx
    mov esp, ebp
    pop ebp
    ret

/* Build <hl.exe-dir>\aom\SAVE\<slot>.aom-audio. Slot is restricted to safe ASCII. */
BuildSidecarPath:
    push ebp
    mov ebp, esp
    push ebx
    push esi
    push edi
    push ecx
    push edx
    call GetPatchBase
    mov ebx, eax
    call ResolveApis
    test eax, eax
    jz .Lpath_fail

    /* GetModuleFileNameW(NULL, buffer, 520). */
    push 520
    lea eax, [ebx + PATH_BUFFER_OFF]
    push eax
    push 0
    call dword ptr [ebx + PTR_GETMODULEFILENAMEW_OFF]
    test eax, eax
    jz .Lpath_fail
    cmp eax, 430
    jae .Lpath_fail

    /* Find the last backslash and truncate after it. */
    lea edi, [ebx + PATH_BUFFER_OFF]
    lea edi, [edi + eax*2]
.Lfind_last_slash:
    dec edi
    cmp word ptr [edi], 0x5c
    jne .Lfind_last_slash
    lea edi, [edi+2]

    /* Append the active AOM mod save directory. */
    lea esi, [ebx + MOD_SAVE_PREFIX_OFF]
.Lcopy_prefix:
    mov al, byte ptr [esi]
    test al, al
    jz .Lcopy_slot_start
    mov byte ptr [edi], al
    mov byte ptr [edi+1], 0
    add edi, 2
    inc esi
    jmp .Lcopy_prefix

.Lcopy_slot_start:
    mov esi, dword ptr [ebp+8]
    xor ecx, ecx
.Lcopy_slot:
    cmp ecx, 63
    jae .Lpath_fail
    mov al, byte ptr [esi]
    test al, al
    jz .Lslot_done
    /* Permit [A-Za-z0-9_-] only. */
    cmp al, 'a'
    jb .Lcheck_upper
    cmp al, 'z'
    jbe .Lslot_char_ok
.Lcheck_upper:
    cmp al, 'A'
    jb .Lcheck_digit
    cmp al, 'Z'
    jbe .Lslot_char_ok
.Lcheck_digit:
    cmp al, '0'
    jb .Lcheck_punct
    cmp al, '9'
    jbe .Lslot_char_ok
.Lcheck_punct:
    cmp al, '_'
    je .Lslot_char_ok
    cmp al, '-'
    jne .Lpath_fail
.Lslot_char_ok:
    mov byte ptr [edi], al
    mov byte ptr [edi+1], 0
    add edi, 2
    inc esi
    inc ecx
    jmp .Lcopy_slot
.Lslot_done:
    test ecx, ecx
    jz .Lpath_fail

    lea esi, [ebx + SIDECAR_SUFFIX_OFF]
.Lcopy_suffix:
    mov al, byte ptr [esi]
    mov byte ptr [edi], al
    mov byte ptr [edi+1], 0
    add edi, 2
    inc esi
    test al, al
    jnz .Lcopy_suffix

    mov eax, 1
    jmp .Lpath_done
.Lpath_fail:
    xor eax, eax
.Lpath_done:
    pop edx
    pop ecx
    pop edi
    pop esi
    pop ebx
    mov esp, ebp
    pop ebp
    ret

WriteSidecar:
    push ebp
    mov ebp, esp
    push ebx
    push esi
    push edi
    call GetPatchBase
    mov ebx, eax
    push dword ptr [ebp+8]
    call BuildSidecarPath
    add esp, 4
    test eax, eax
    jz .Lwrite_fail

    /* Remove any stale sidecar before replacing it. */
    lea eax, [ebx + PATH_BUFFER_OFF]
    push eax
    call dword ptr [ebx + PTR_DELETEFILEW_OFF]

    /* CreateFileW(path, GENERIC_WRITE, FILE_SHARE_READ|WRITE, NULL, CREATE_ALWAYS, NORMAL, NULL). */
    push 0
    push 0x80
    push 2
    push 0
    push 3
    push 0x40000000
    lea eax, [ebx + PATH_BUFFER_OFF]
    push eax
    call dword ptr [ebx + PTR_CREATEFILEW_OFF]
    cmp eax, -1
    je .Lwrite_fail
    mov esi, eax

    /* Header: magic + version. */
    lea eax, [ebx + SIDECAR_HEADER_OFF]
    push 0
    lea ecx, [ebx + BYTES_DONE_OFF]
    push ecx
    push 8
    push eax
    push esi
    call dword ptr [ebx + PTR_WRITEFILE_OFF]
    test eax, eax
    jz .Lwrite_close_bad
    cmp dword ptr [ebx + BYTES_DONE_OFF], 8
    jne .Lwrite_close_bad

    /* Payload contains the snapshot, slot name, clock, and both records. */
    lea eax, [ebx + STATE_MAGIC_OFF]
    push 0
    lea ecx, [ebx + BYTES_DONE_OFF]
    push ecx
    push PAYLOAD_SIZE
    push eax
    push esi
    call dword ptr [ebx + PTR_WRITEFILE_OFF]
    test eax, eax
    jz .Lwrite_close_bad
    mov edx, PAYLOAD_SIZE
    cmp dword ptr [ebx + BYTES_DONE_OFF], edx
    jne .Lwrite_close_bad

    push esi
    call dword ptr [ebx + PTR_CLOSEHANDLE_OFF]
    mov eax, 1
    jmp .Lwrite_done
.Lwrite_close_bad:
    push esi
    call dword ptr [ebx + PTR_CLOSEHANDLE_OFF]
    lea eax, [ebx + PATH_BUFFER_OFF]
    push eax
    call dword ptr [ebx + PTR_DELETEFILEW_OFF]
.Lwrite_fail:
    xor eax, eax
.Lwrite_done:
    pop edi
    pop esi
    pop ebx
    mov esp, ebp
    pop ebp
    ret

ReadSidecar:
    push ebp
    mov ebp, esp
    push ebx
    push esi
    push edi
    call GetPatchBase
    mov ebx, eax
    push dword ptr [ebp+8]
    call BuildSidecarPath
    add esp, 4
    test eax, eax
    jz .Lread_fail

    /* CreateFileW(path, GENERIC_READ, FILE_SHARE_READ|WRITE, NULL, OPEN_EXISTING, NORMAL, NULL). */
    push 0
    push 0x80
    push 3
    push 0
    push 3
    push 0x80000000
    lea eax, [ebx + PATH_BUFFER_OFF]
    push eax
    call dword ptr [ebx + PTR_CREATEFILEW_OFF]
    cmp eax, -1
    je .Lread_fail
    mov esi, eax

    lea eax, [ebx + SIDECAR_HEADER_OFF]
    push 0
    lea ecx, [ebx + BYTES_DONE_OFF]
    push ecx
    push 8
    push eax
    push esi
    call dword ptr [ebx + PTR_READFILE_OFF]
    test eax, eax
    jz .Lread_close_bad
    cmp dword ptr [ebx + BYTES_DONE_OFF], 8
    jne .Lread_close_bad
    cmp dword ptr [ebx + SIDECAR_HEADER_OFF], 0x4D4F4141 /* AAOM */
    jne .Lread_close_bad
    cmp dword ptr [ebx + SIDECAR_HEADER_OFF+4], 2
    jne .Lread_close_bad

    lea eax, [ebx + STATE_MAGIC_OFF]
    push 0
    lea ecx, [ebx + BYTES_DONE_OFF]
    push ecx
    push PAYLOAD_SIZE
    push eax
    push esi
    call dword ptr [ebx + PTR_READFILE_OFF]
    test eax, eax
    jz .Lread_close_bad
    mov edx, PAYLOAD_SIZE
    cmp dword ptr [ebx + BYTES_DONE_OFF], edx
    jne .Lread_close_bad

    push esi
    call dword ptr [ebx + PTR_CLOSEHANDLE_OFF]

    /* Ensure the payload corresponds to this exact slot and is structurally valid. */
    cmp dword ptr [ebx + STATE_MAGIC_OFF], 0x4D4F4141
    jne .Lread_fail
    cmp dword ptr [ebx + STATE_COUNT_OFF], 2
    ja .Lread_fail
    mov esi, dword ptr [ebp+8]
    lea edi, [ebx + SAVE_SLOT_NAME_OFF]
    mov ecx, 64
.Lvalidate_slot:
    test ecx, ecx
    jz .Lread_success
    mov al, byte ptr [esi]
    cmp al, byte ptr [edi]
    jne .Lread_fail
    inc esi
    inc edi
    dec ecx
    test al, al
    jnz .Lvalidate_slot
.Lread_success:
    mov eax, 1
    jmp .Lread_done
.Lread_close_bad:
    push esi
    call dword ptr [ebx + PTR_CLOSEHANDLE_OFF]
.Lread_fail:
    xor eax, eax
.Lread_done:
    pop edi
    pop esi
    pop ebx
    mov esp, ebp
    pop ebp
    ret

/* Capture matching active WAV channels at the exact save call. */
CaptureState:
    push ebp
    mov ebp, esp
    push ebx
    push esi
    push edi
    push ecx
    push edx
    call GetPatchBase
    mov ebx, eax

    mov dword ptr [ebx + STATE_MAGIC_OFF], 0
    mov dword ptr [ebx + STATE_COUNT_OFF], 0
    mov dword ptr [ebx + SOUND_TIME_SAVED_OFF], 0
    lea edi, [ebx + RECORD1_OFF]
    xor eax, eax
    mov ecx, 22                  /* two records, 0x2c bytes each */
    rep stosd

    lea edi, [ebx + SAVE_SLOT_NAME_OFF]
    xor eax, eax
    mov ecx, 64
    rep stosb
    mov esi, dword ptr [ebp+8]
    lea edi, [ebx + SAVE_SLOT_NAME_OFF]
    mov ecx, 63
.Lcopy_slot_name:
    test ecx, ecx
    jz .Lslot_name_done
    lodsb
    stosb
    test al, al
    jz .Lslot_name_done
    dec ecx
    jmp .Lcopy_slot_name
.Lslot_name_done:

    mov eax, dword ptr [ebx + SOUND_TIME_VA - PATCH_VA]
    mov dword ptr [ebx + SOUND_TIME_SAVED_OFF], eax

    lea esi, [ebx + CHAN_TABLE_VA - PATCH_VA]
    mov ecx, 128
.Lscan_channels:
    mov eax, dword ptr [esi]
    test eax, eax
    jz .Lscan_next

    push ecx
    push esi
    push edi
    mov edi, eax              /* sfx_t*; its first member is name[64] */
    lea esi, [ebx + SOUND_NAME1_OFF]
    mov ecx, 19               /* strlen("aompa/sickness.wav") + NUL */
    repe cmpsb
    pop edi
    pop esi
    pop ecx
    je .Lfound_sound1

    mov eax, dword ptr [esi]
    push ecx
    push esi
    push edi
    mov edi, eax
    lea esi, [ebx + SOUND_NAME2_OFF]
    mov ecx, 20               /* strlen("player/breathe1.wav") + NUL */
    repe cmpsb
    pop edi
    pop esi
    pop ecx
    je .Lfound_sound2
    jmp .Lscan_next

.Lfound_sound1:
    mov eax, dword ptr [esi+0x0c]
    cmp eax, dword ptr [ebx + SOUND_TIME_VA - PATCH_VA]
    jbe .Lscan_next
    /* ambient_generic is emitted on CHAN_STATIC (6), not a dynamic channel. */
    cmp dword ptr [esi+0x1c], 6
    jne .Lscan_next
    cmp dword ptr [esi+0x34], -1
    jne .Lscan_next
    /* Neutral input pitch 100 is stored as internal pitch step 50 in +0x3C. */
    cmp dword ptr [esi+0x3c], 50
    jne .Lscan_next
    cmp dword ptr [ebx + RECORD1_OFF], 1
    je .Lscan_next
    lea edi, [ebx + RECORD1_OFF]
    call StoreRecord
    jmp .Lscan_next
.Lfound_sound2:
    mov eax, dword ptr [esi+0x0c]
    cmp eax, dword ptr [ebx + SOUND_TIME_VA - PATCH_VA]
    jbe .Lscan_next
    /* ambient_generic is emitted on CHAN_STATIC (6), not a dynamic channel. */
    cmp dword ptr [esi+0x1c], 6
    jne .Lscan_next
    cmp dword ptr [esi+0x34], -1
    jne .Lscan_next
    cmp dword ptr [esi+0x3c], 50
    jne .Lscan_next
    cmp dword ptr [ebx + RECORD2_OFF], 1
    je .Lscan_next
    lea edi, [ebx + RECORD2_OFF]
    call StoreRecord

.Lscan_next:
    add esi, 0x40
    dec ecx
    jnz .Lscan_channels

    cmp dword ptr [ebx + STATE_COUNT_OFF], 0
    je .Lcap_done
    mov dword ptr [ebx + STATE_MAGIC_OFF], 0x4D4F4141
.Lcap_done:
    pop edx
    pop ecx
    pop edi
    pop esi
    pop ebx
    mov esp, ebp
    pop ebp
    ret

/* ESI = live channel, EDI = destination record, EBX = patch base. */
StoreRecord:
    mov eax, dword ptr [esi+0x10]
    mov dword ptr [edi+0x04], eax
    mov eax, dword ptr [esi+0x18]
    mov dword ptr [edi+0x08], eax
    mov eax, dword ptr [esi+0x1c]
    mov dword ptr [edi+0x0c], eax
    mov eax, dword ptr [esi+0x30]
    mov dword ptr [edi+0x10], eax
    mov eax, dword ptr [esi+0x2c]
    mov dword ptr [edi+0x14], eax
    mov eax, dword ptr [esi+0x3c]
    mov dword ptr [edi+0x18], eax
    mov eax, dword ptr [esi+0x0c]
    mov dword ptr [edi+0x1c], eax
    mov eax, dword ptr [esi+0x20]
    mov dword ptr [edi+0x20], eax
    mov eax, dword ptr [esi+0x24]
    mov dword ptr [edi+0x24], eax
    mov eax, dword ptr [esi+0x28]
    mov dword ptr [edi+0x28], eax
    mov dword ptr [edi], 1
    inc dword ptr [ebx + STATE_COUNT_OFF]
    ret

/* Restore state after a successful load of a matching slot. */
RestoreState:
    push ebp
    mov ebp, esp
    sub esp, 4
    push ebx
    push esi
    push edi
    push ecx
    push edx
    call GetPatchBase
    mov ebx, eax

    cmp dword ptr [ebx + STATE_MAGIC_OFF], 0x4D4F4141
    jne .Lrestore_done
    mov esi, dword ptr [ebp+8]
    lea edi, [ebx + SAVE_SLOT_NAME_OFF]
    mov ecx, 64
.Lcmp_slot:
    test ecx, ecx
    jz .Lslot_match
    mov al, byte ptr [esi]
    cmp al, byte ptr [edi]
    jne .Lrestore_done
    inc esi
    inc edi
    dec ecx
    test al, al
    jnz .Lcmp_slot
.Lslot_match:

    mov eax, dword ptr [ebx + SOUND_TIME_VA - PATCH_VA]
    sub eax, dword ptr [ebx + SOUND_TIME_SAVED_OFF]
    mov dword ptr [ebp-4], eax

    lea eax, [ebx + RECORD1_OFF]
    lea ecx, [ebx + SOUND_NAME1_OFF]
    push dword ptr [ebp-4]
    push ecx
    push eax
    call RestoreOne
    add esp, 12

    lea eax, [ebx + RECORD2_OFF]
    lea ecx, [ebx + SOUND_NAME2_OFF]
    push dword ptr [ebp-4]
    push ecx
    push eax
    call RestoreOne
    add esp, 12

.Lrestore_done:
    pop edx
    pop ecx
    pop edi
    pop esi
    pop ebx
    mov esp, ebp
    pop ebp
    ret

/* Args: record, sound-name, sound-time delta. */
RestoreOne:
    push ebp
    mov ebp, esp
    sub esp, 4                  /* local sfx_t* */
    push ebx
    push esi
    push edi
    push ecx
    push edx
    call GetPatchBase
    mov ebx, eax

    mov esi, dword ptr [ebp+8]
    cmp dword ptr [esi], 1
    jne .Lone_done
    mov edi, dword ptr [ebp+0x0c]

    /* S_FindName(name, NULL) returns the sfx_t* required by S_StartStaticSound. */
    push 0
    push edi
    mov eax, S_FIND_NAME_VA - PATCH_VA
    add eax, ebx
    call eax
    add esp, 8
    test eax, eax
    jz .Lone_done
    mov dword ptr [ebp-4], eax

    /* Recreate static channel: ent, channel, sfx_t*, origin, volume, attenuation, flags, pitch. */
    push 100                         /* neutral input pitch */
    push 0                           /* flags */

    movss xmm0, dword ptr [esi+0x14]
    mulss xmm0, dword ptr [ebx + FLOAT1000_OFF]
    movd eax, xmm0
    push eax                         /* attenuation; engine divides input by 1000 */

    mov eax, dword ptr [esi+0x10]
    cvtsi2ss xmm0, eax
    divss xmm0, dword ptr [ebx + FLOAT255_OFF]
    movd eax, xmm0
    push eax                         /* volume */

    lea eax, [esi+0x20]
    push eax                         /* origin */
    push dword ptr [ebp-4]            /* sfx_t*, not a char* */
    push dword ptr [esi+0x0c]         /* channel */
    push dword ptr [esi+0x08]         /* entity */

    mov eax, S_START_STATIC_SOUND_VA - PATCH_VA
    add eax, ebx
    call eax
    add esp, 32

    /* Locate the newly created/reused channel by exact sfx_t*, entity and channel. */
    lea edx, [ebx + CHAN_TABLE_VA - PATCH_VA]
    mov ecx, 128
.Lfind_new_channel:
    mov eax, dword ptr [edx]
    cmp eax, dword ptr [ebp-4]
    jne .Lfind_next_channel
    mov eax, dword ptr [esi+0x08]
    cmp dword ptr [edx+0x18], eax
    jne .Lfind_next_channel
    mov eax, dword ptr [esi+0x0c]
    cmp dword ptr [edx+0x1c], eax
    jne .Lfind_next_channel

    mov eax, dword ptr [esi+0x04]
    mov dword ptr [edx+0x10], eax         /* sample cursor */
    mov eax, dword ptr [esi+0x10]
    mov dword ptr [edx+0x30], eax         /* base volume */
    mov eax, dword ptr [esi+0x14]
    mov dword ptr [edx+0x2c], eax         /* attenuation */
    mov eax, dword ptr [esi+0x18]
    mov dword ptr [edx+0x3c], eax         /* internal pitch step */
    mov eax, dword ptr [esi+0x1c]
    add eax, dword ptr [ebp+0x10]
    mov dword ptr [edx+0x0c], eax         /* new sound clock + saved remaining length */
    jmp .Lone_done
.Lfind_next_channel:
    add edx, 0x40
    dec ecx
    jnz .Lfind_new_channel

.Lone_done:
    pop edx
    pop ecx
    pop edi
    pop esi
    pop ebx
    mov esp, ebp
    pop ebp
    ret

PatchEnd:

.align 16
StateMagic:       .long 0
StateCount:       .long 0
SoundTimeSaved:   .long 0
SaveSlotName:     .space 64, 0
.align 16
Record1:          .space 0x2c, 0
Record2:          .space 0x2c, 0
Float255:         .float 255.0
Float1000:        .float 1000.0
SoundName1:       .asciz "aompa/sickness.wav"
SoundName2:       .asciz "player/breathe1.wav"
Kernel32A:        .asciz "kernel32.dll"
ApiGetModuleFileNameW: .asciz "GetModuleFileNameW"
ApiCreateFileW:   .asciz "CreateFileW"
ApiWriteFile:     .asciz "WriteFile"
ApiReadFile:      .asciz "ReadFile"
ApiCloseHandle:   .asciz "CloseHandle"
ApiDeleteFileW:   .asciz "DeleteFileW"
ModSavePrefix:    .asciz "aom\\SAVE\\"
SidecarSuffix:   .asciz ".aom-audio"
.align 4
SidecarHeader:    .long 0x4D4F4141, 2
BytesDone:        .long 0
PtrGetModuleFileNameW: .long 0
PtrCreateFileW:   .long 0
PtrWriteFile:     .long 0
PtrReadFile:      .long 0
PtrCloseHandle:   .long 0
PtrDeleteFileW:   .long 0
PathBuffer:       .space 1040, 0

.equ STATE_MAGIC_OFF, StateMagic - PatchStart
.equ STATE_COUNT_OFF, StateCount - PatchStart
.equ SOUND_TIME_SAVED_OFF, SoundTimeSaved - PatchStart
.equ SAVE_SLOT_NAME_OFF, SaveSlotName - PatchStart
.equ RECORD1_OFF, Record1 - PatchStart
.equ RECORD2_OFF, Record2 - PatchStart
.equ SOUND_NAME1_OFF, SoundName1 - PatchStart
.equ SOUND_NAME2_OFF, SoundName2 - PatchStart
.equ FLOAT255_OFF, Float255 - PatchStart
.equ FLOAT1000_OFF, Float1000 - PatchStart
.equ KERNEL32_A_OFF, Kernel32A - PatchStart
.equ API_GETMODULEFILENAMEW_OFF, ApiGetModuleFileNameW - PatchStart
.equ API_CREATEFILEW_OFF, ApiCreateFileW - PatchStart
.equ API_WRITEFILE_OFF, ApiWriteFile - PatchStart
.equ API_READFILE_OFF, ApiReadFile - PatchStart
.equ API_CLOSEHANDLE_OFF, ApiCloseHandle - PatchStart
.equ API_DELETEFILEW_OFF, ApiDeleteFileW - PatchStart
.equ MOD_SAVE_PREFIX_OFF, ModSavePrefix - PatchStart
.equ SIDECAR_SUFFIX_OFF, SidecarSuffix - PatchStart
.equ SIDECAR_HEADER_OFF, SidecarHeader - PatchStart
.equ BYTES_DONE_OFF, BytesDone - PatchStart
.equ PTR_GETMODULEFILENAMEW_OFF, PtrGetModuleFileNameW - PatchStart
.equ PTR_CREATEFILEW_OFF, PtrCreateFileW - PatchStart
.equ PTR_WRITEFILE_OFF, PtrWriteFile - PatchStart
.equ PTR_READFILE_OFF, PtrReadFile - PatchStart
.equ PTR_CLOSEHANDLE_OFF, PtrCloseHandle - PatchStart
.equ PTR_DELETEFILEW_OFF, PtrDeleteFileW - PatchStart
.equ PATH_BUFFER_OFF, PathBuffer - PatchStart
.equ PAYLOAD_SIZE, (Record2 + 0x2c) - StateMagic
