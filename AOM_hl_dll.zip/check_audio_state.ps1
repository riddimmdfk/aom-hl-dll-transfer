﻿$ErrorActionPreference = 'Stop'
function Wait-End { Read-Host 'Нажмите Enter для закрытия окна' | Out-Null }
try {
    $pf86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
    if ([string]::IsNullOrWhiteSpace($pf86)) { $pf86 = $env:ProgramFiles }
    $defaultRoot = Join-Path $pf86 'Steam\steamapps\common\Half-Life'
    $entered = Read-Host "Папка Half-Life (Enter = $defaultRoot)"
    if ([string]::IsNullOrWhiteSpace($entered)) { $root = $defaultRoot } else { $root = $entered.Trim().Trim('"') }
    $root = [IO.Path]::GetFullPath($root)
    $slot = Read-Host 'Имя слота сохранения (например quick)'
    if ([string]::IsNullOrWhiteSpace($slot) -or $slot -notmatch '^[A-Za-z0-9_-]{1,62}$') { throw 'Недопустимое имя слота.' }
    $file = Join-Path $root ("aom\SAVE\{0}.aom-audio" -f $slot)
    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw "Файл состояния не найден: $file`nСначала выполни сохранение при воспроизводимом целевом звуке." }
    $b = [IO.File]::ReadAllBytes($file)
    if ($b.Length -lt 176) { throw "Файл слишком короткий: $($b.Length) байт." }
    $headerMagic = [BitConverter]::ToUInt32($b,0)
    $version = [BitConverter]::ToUInt32($b,4)
    $stateMagic = [BitConverter]::ToUInt32($b,8)
    $count = [BitConverter]::ToUInt32($b,12)
    $soundTime = [BitConverter]::ToUInt32($b,16)
    $savedSlot = [Text.Encoding]::ASCII.GetString($b,20,64).TrimEnd([char]0)
    if ($headerMagic -ne 0x4D4F4141 -or $version -ne 2) { throw 'Заголовок файла не соответствует формату AOM Audio Resume v0.2.' }
    Write-Host ''
    Write-Host "Файл: $file"
    Write-Host "Размер: $($b.Length) байт"
    Write-Host "Слот в файле: $savedSlot"
    Write-Host "Sound clock при сохранении: $soundTime"
    Write-Host "Число захваченных звуков: $count"
    if ($savedSlot -ne $slot) { Write-Host 'ВНИМАНИЕ: имя слота внутри файла не совпадает с запрошенным.' -ForegroundColor Yellow }
    if ($stateMagic -ne 0x4D4F4141 -or $count -eq 0) {
        Write-Host 'Целевые звуки не были обнаружены в момент сохранения (либо снимок пуст).' -ForegroundColor Yellow
    } else {
        $defs = @(
            @{ Name='aompa/sickness.wav'; Offset=88 },
            @{ Name='player/breathe1.wav'; Offset=132 }
        )
        foreach ($d in $defs) {
            $o = [int]$d.Offset
            $valid = [BitConverter]::ToUInt32($b,$o)
            if ($valid -eq 1) {
                $cursor = [BitConverter]::ToUInt32($b,$o+4)
                $entity = [BitConverter]::ToUInt32($b,$o+8)
                $channel = [BitConverter]::ToUInt32($b,$o+12)
                $volume = [BitConverter]::ToUInt32($b,$o+16)
                $atten = [BitConverter]::ToSingle($b,$o+20)
                $pitch = [BitConverter]::ToUInt32($b,$o+24)
                $end = [BitConverter]::ToUInt32($b,$o+28)
                Write-Host ''
                Write-Host "Захвачен: $($d.Name)" -ForegroundColor Green
                Write-Host "  Позиция: $cursor; entity: $entity; channel: $channel; volume: $volume; attenuation: $atten; pitch step: $pitch; end time: $end"
            } else {
                Write-Host "Не захвачен: $($d.Name)" -ForegroundColor Yellow
            }
        }
    }
    Write-Host ''
    Wait-End
}
catch {
    Write-Host ''
    Write-Host ('ОШИБКА: ' + $_.Exception.Message) -ForegroundColor Red
    Wait-End
    exit 1
}
